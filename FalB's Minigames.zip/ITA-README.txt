Quindi:
Questo � un mondo pieno di Minigiochi (pi� o meno).
Siate solo sicuri di mettere i file del mondo nella cartella corretta
Per qualsiasi informazione: youtube.com/channel/UCq8DZDldrbqdtVtZZxmJNgg

-FalB